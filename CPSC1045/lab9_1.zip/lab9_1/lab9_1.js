let c = document.getElementById('myCanvas');
let b1 = document.getElementById('button1');
let ctx = c.getContext('2d');
b1.addEventListener("click", startGame);
let timerID = null;
let x = 0;
let y = 0;
let a = 0;
let b = 0;

function startGame() {
    clearInterval(timerID);
    timerID = null;

    if (timerID == null) {

        timerID = setInterval(moveDot, 100);
        a = 30 * Math.random() - 5;
        b = 30 * Math.random() - 5;

    }
}
function moveDot() {

    if (x >= 330 || y >= 330) {
        alert('Oops!The dot has escaped!')
        x = 0;
        y = 0;
        clearInterval(timerID);
        timerID = null;
    }
    else {
        ctx.clearRect(0, 0, 600, 600);
        ctx.save();
        ctx.beginPath();
        ctx.translate(300, 300);
        ctx.arc(x, y, 20, 0, 2 * Math.PI);
        ctx.fillStyle = "green";
        ctx.fill();
        x += a;
        y += b;
        ctx.restore();
        ctx.save();

    }
}
c.addEventListener("click", clickDot)
function clickDot(e) {
    let clickX = e.offsetX;
    let clickY = e.offsetY;
    let c = (clickX - x) ** 2 + (clickY - y) ** 2;
    let r = (((x + 20) - x) ** 2 + ((y + 20) - y) ** 2);
    if (Math.sqrt(c) <= r) {
        alert('BIngo! The dot is caught and will disappear')
        clearInterval(timerID);
        timerID = null;
        ctx.clearRect(0, 0, 600, 600);
        ctx.restore();
    }

}

