let c = document.getElementById('myCanvas');
let bt1 = document.getElementById('button1');
let ctx = c.getContext('2d');
let b1 = document.getElementById('box1');
let b2 = document.getElementById('box2');
let myArray = new Array();
let timerID = null;
let r = 16;
let dotX = [];
let dotY = [];
let dotmY = [];
let dotColor = [];
let a=b1.value+0;
bt1.addEventListener("click", runAnimation);//For animation -moving the dots in the canvas.
bt1.addEventListener('click', setTime);//this will start the timer in the background.
function runAnimation() {
    clearInterval(timerID);
    timerID = null;

    for (i = 0; i <=40 ; i++) {
        dotX[i] = Math.random() * 650;
        dotY[i] = 0;
        dotmY[i] =10*Math.random()+10;
        dotColor[i] = 'rgb(' + Math.floor(Math.random() * 256) + ',' + Math.floor(Math.random() * 256) + ',' + Math.floor(Math.random() * 256) + ')'

    }
    if (timerID == null) {
        timerID = setInterval(moveDots, 100);
    }

}
function moveDots() {
    ctx.clearRect(0, 0, 650, 600);
    for (let i = 0; i <=40; i++) {
        ctx.beginPath();
        ctx.arc(dotX[i], dotY[i], 16, 0, 2 * Math.PI);
        dotY[i] += dotmY[i];
        ctx.fillStyle = dotColor[i];
        ctx.fill();
        if (dotY[i] >= 300) {
            dotY[i] = 0;
        }
    }
}

c.addEventListener('click', clickDot)
function clickDot(e) {
    let clickX = e.offsetX;
    let clickY = e.offsetY;
    for (i = 0; i < dotX.length; i++) {
        let c = ((clickX - dotX[i]) ** 2) + ((clickY - dotY[i]) ** 2);
        let r = 16;
        console.log(Math.sqrt(c), r)
        if (Math.sqrt(c) <= r) {
            myArray.push(1);
            b1.value = myArray.length;
            dotX.splice(i, 1);
            dotY.splice(i, 1);
            dotmY.splice(i, 1);
            dotColor.splice(i, 1);
        }
    }
}//this was for click on the canvas and array is used to update the points earned.

function setTime() {
    setTimeout(myFunction, 30000);
}
function myFunction() {
    if (b1.value >= 30) {
        clearInterval(timerID);
        ctx.clearRect(0, 0, 650, 500);
        ctx.font = "70px arial";
        ctx.strokeText("Congrats! You Win!", 10, 250);
        ctx.strokeStyle = 'rgb(' + Math.floor(Math.random() * 256) + ',' + Math.floor(Math.random() * 256) + ',' + Math.floor(Math.random() * 256) + ')';
        ctx.fillText("Congrats! You Win!", 10, 250);
        ctx.fillStyle = 'rgb(' + Math.floor(Math.random() * 256) + ',' + Math.floor(Math.random() * 256) + ',' + Math.floor(Math.random() * 256) + ')';
    }
    else {
        alert('Your time is out and your score is ' + a + '. Better luck next time.');
        clearInterval(timerID);
        ctx.clearRect(0, 0, 650, 500);
        ctx.font = "100px arial";
        ctx.strokeText("Game Over!", 40, 250);
        ctx.strokeStyle = 'rgb(' + Math.floor(Math.random() * 256) + ',' + Math.floor(Math.random() * 256) + ',' + Math.floor(Math.random() * 256) + ')';
        ctx.fillText("Game Over!", 40, 250);
        ctx.fillStyle = 'rgb(' + Math.floor(Math.random() * 256) + ',' + Math.floor(Math.random() * 256) + ',' + Math.floor(Math.random() * 256) + ')';
    }

}//setTime is for timer and I used if else statement to show the win or lose.
/*I used the knowledge from lectures and previous labs and I also used some code from w3c schools site.*/