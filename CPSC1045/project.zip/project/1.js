let c=document.getElementById('myCanvas');
let ctx = c.getContext('2d');
let img=document.getElementById("fire");
window.onload=function(){
    ctx.drawImage(img,0, 300);
}