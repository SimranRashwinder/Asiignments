let c = document.getElementById('myCanvas');
let bt1 = document.getElementById('button1');
let ctx = c.getContext('2d');
let img = document.getElementById("fire");
let b1=document.getElementById('box1');
window.onload = function () {
    ctx.drawImage(img, 0, 300);
}
let myArray=new Array();
let timerID = null;
let x = Math.random() * 600;
let y = 0;
let a = 0;
let b = 0;
let r = 20;//drawing dot
let dotX = [];
let dotY = [];
let dotmY = [];
let dotColor = [];//animation
bt1.addEventListener("click", runAnimation);
function runAnimation() {
    clearInterval(timerID);
    timerID = null;

    for (i = 0; i <=20; i++) {
        dotX[i] = Math.random()*600;
        dotY[i] = 0;
        dotmY[i] =  5 * Math.random()+5;;
        dotColor[i] = 'rgb(' + Math.floor(Math.random() * 256) + ',' + Math.floor(Math.random() * 256) + ',' + Math.floor(Math.random() * 256) + ')'

    }
    if (timerID == null) {
        timerID = setInterval(moveDots, 100);
    }

}
function moveDots() {
    ctx.clearRect(0, 0, 600, 600);
    for (let i = 0; i <20; i++) {
        ctx.beginPath();
        ctx.arc(dotX[i], dotY[i],20, 0, 2 * Math.PI);
        dotY[i] += dotmY[i];
        ctx.fillStyle = dotColor[i];
        ctx.fill();
        if(dotY[i]>=500){
            dotY[i]=0;
        }
    }
}

/*function startGame() {
    clearInterval(timerID);
    timerID = null;

    if (timerID == null) {

        timerID = setInterval(moveDot, 100);
        a = 30 * Math.random() - 5;
        b = 30 * Math.random() - 5;

    }
}
function moveDot() {

    if (y >= 300){
       alert('You lost');
       x = 300;
       y = 300;
        clearInterval(timerID);
        timerID = null;
    }
    
    else {
        for (i = 0; i <= 40; i++) {
            ctx.clearRect(0,0,600,300);
            ctx.save();
            ctx.restore();
            ctx.beginPath();
            ctx.arc(x, y, r, 0, 2 * Math.PI);
            ctx.fillStyle = 'rgb(' + Math.floor(Math.random() * 256) + ',' + Math.floor(Math.random() * 256) + ',' + Math.floor(Math.random() * 256) + ')';
            ctx.fill();
            y += b;
            ctx.restore();
            ctx.save();
        }
    }
}*/
c.addEventListener('click', clickDot)
function clickDot(e) {
    let clickX = e.offsetX;
    let clickY = e.offsetY;
    for(i=0;i<dotX.length;i++){
    let c = ((clickX - dotX[i]) ** 2) + ((clickY - dotY[i]) ** 2);
    let r = 20;
    console.log(Math.sqrt(c),r)
    if (Math.sqrt(c) <= r) {
        myArray.push(1);
        b1.value=myArray.length;
        dotX.splice(i,1);
        dotY.splice(i,1);
        dotmY.splice(i,1);
        dotColor.splice(i,1);
    }
}}
