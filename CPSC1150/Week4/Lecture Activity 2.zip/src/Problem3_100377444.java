
public class Problem3_100377444 {

	public static void main(String[] args) {
		for (int i= '!'; i <'+'; i++){
		    System.out.print(((char)i) +" ");
		}
		System.out.println("\n");
	
        for (int i= '+'; i <'5'; i++){
		    System.out.print(((char)i) + " ");
		}
        System.out.println("\n");
        
        for (int i= '5'; i <'?'; i++){
		    System.out.print(((char)i) + " ");
		}
        System.out.println("\n");
        
        for (int i= '?'; i <'I'; i++){
		    System.out.print(((char)i) + " ");
		}
        System.out.println("\n");
        
        for (int i= 'I'; i <'S'; i++){
		    System.out.print(((char)i) + " ");
		}
        System.out.println("\n");
        
        for (int i= 'S'; i <']'; i++){
		    System.out.print(((char)i) + " ");
		}
        System.out.println("\n");
        
        for (int i= ']'; i <'g'; i++){
		    System.out.print(((char)i) + " ");
		}
        System.out.println("\n");
        
        for (int i= 'g'; i <'q'; i++){
		    System.out.print(((char)i) + " ");
		}
        System.out.println("\n");
        
        for (int i= 'q'; i <'{'; i++){
		    System.out.print(((char)i) + " ");
		}
        System.out.println("\n");

        for (int i= '{'; i <='~'; i++){
		    System.out.print(((char)i) + " ");
		}
        
        
        
	}

}
