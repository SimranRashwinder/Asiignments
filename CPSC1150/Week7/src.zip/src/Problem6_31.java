import java.util.Scanner;

public class Problem6_31 {
	public static void main(String[] args) {
        long number;
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a credit card number as a long integer: ");
        number = input.nextLong();

	}
	public static boolean isValid(long number) {
		return true;
	}
	public static int sumOfDoubleEvenPlace(long number) {
		int sum = 0;
		return sum;
	}
	

}
