import javax.print.DocFlavor;
import java.util.Scanner;

/**This is Student class which contains all instance variables and methods*/
public class Student {

      private String firstName;
      private String lastName;

      private String StudentName;
      private String address;
      private int studentNumber;
      private double gpa;
      private int StudentNumber;
      private String loginId;
      private  int numberOfCourses;
      private int gradePoints;
      public static int lastAssignedNumber = 10000;

      public Student() {
            lastAssignedNumber++;
            StudentNumber = lastAssignedNumber;
      }
      public Student(String address, String StdName, String FIRST, String LAST) {
            StdName = FIRST + LAST ;
      }

      Scanner input = new Scanner(System.in);
      /**This method is used to get the name of the student*/
      public String getStudentName() {
            firstName = input.next();
            System.out.println("Enter the last NAME:");
            lastName = input.next();
            this.StudentName = firstName + lastName;
            return StudentName;
      }

      public String getAddress() {
            return address;
      }

      public int getStudentNumber(){
            return StudentNumber;
      }
      public int addCourse(){
            numberOfCourses++;
            gradePoints++;
            return numberOfCourses;
      }
/**calculateGpa will calculate the gpa of every student which is total grades/total credits*/

       public double calculateGpa(){
            gpa = gradePoints/numberOfCourses*3;
            return gpa;
      }
/**This method will calculate the loginId */
      public String getLoginId() {
            System.out.println("Enter the first NAME:");
            firstName = input.next();
            System.out.println("Enter the last NAME:");
            lastName = input.next();
           String s = Integer.toString(studentNumber);
           loginId = firstName.substring(0,0) + lastName.substring(0,2) + s.substring(s.length()-3,s.length()-1) ;
            return loginId;
      }



}
